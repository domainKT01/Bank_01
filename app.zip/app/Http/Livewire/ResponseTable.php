<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ResponseTable extends Component
{
    public function render()
    {
        return view('livewire.response-table');
    }
}
